package com.example.irongym.entity

data class DiaEntrenamiento(
    val id: Int,
    val dia: String,
    val descripcion: String,
    val imagenUrl: String
)
