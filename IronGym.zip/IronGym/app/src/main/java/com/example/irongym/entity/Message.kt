package com.example.irongym.entity

data class Message(
    val text: String,
    val sender: String,
    val time: String
)
