package com.example.irongym.entity

data class Choice(
    val message: OpenAiResponseMessage
)