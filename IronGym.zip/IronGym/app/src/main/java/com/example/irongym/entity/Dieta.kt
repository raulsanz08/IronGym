package com.example.irongym.entity

data class Dieta(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val imagenUrl: String
)