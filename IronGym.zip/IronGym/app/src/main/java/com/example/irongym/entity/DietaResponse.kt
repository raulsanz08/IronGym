package com.example.irongym.entity

data class DietaResponse(
    val success: Boolean,
    val dietas: List<Dieta>
)