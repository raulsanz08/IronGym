package com.example.irongym.entity

data class RutinaResponse(
    val success: Boolean,
    val rutinas: List<Rutina>
)