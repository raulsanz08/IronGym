package com.example.irongym.entity

data class Rutina(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val imagenUrl: String
)