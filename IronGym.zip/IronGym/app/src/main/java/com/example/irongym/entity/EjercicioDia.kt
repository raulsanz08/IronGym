package com.example.irongym.entity

data class EjercicioDia(
    val id: Int,
    val dia_entrenamiento_id: Int,
    val nombre: String,
    val repeticiones: String
)
