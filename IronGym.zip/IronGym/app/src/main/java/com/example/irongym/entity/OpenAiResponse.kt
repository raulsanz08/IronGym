package com.example.irongym.entity

data class OpenAiResponse(
    val choices: List<Choice>
)