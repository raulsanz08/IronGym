package com.example.irongym.entity

data class MessageResponse(
    val role:String,
    val content:String
)
