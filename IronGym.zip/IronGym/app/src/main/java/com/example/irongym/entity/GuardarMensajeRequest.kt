package com.example.irongym.entity

data class GuardarMensajeRequest(
    val texto: String,
    val remitente: String
)
