package com.example.irongym.entity

data class MensajeResponse(
    val texto: String,
    val remitente: String,
    val fecha: String
)
