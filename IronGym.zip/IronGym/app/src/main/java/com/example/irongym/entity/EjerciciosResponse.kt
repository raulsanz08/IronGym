package com.example.irongym.entity

data class EjerciciosResponse(
    val success: Boolean,
    val ejercicios: List<EjercicioDia>
)
