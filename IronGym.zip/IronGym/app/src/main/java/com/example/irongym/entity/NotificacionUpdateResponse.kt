package com.example.irongym.entity

data class NotificacionUpdateResponse(
    val activo: Boolean
)
