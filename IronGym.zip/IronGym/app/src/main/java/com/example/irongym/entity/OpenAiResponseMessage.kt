package com.example.irongym.entity

data class OpenAiResponseMessage(
    val role: String,
    val content: String
)