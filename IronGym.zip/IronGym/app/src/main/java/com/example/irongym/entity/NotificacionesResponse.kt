package com.example.irongym.entity

data class NotificacionesResponse(
    val success: Boolean,
    val notificaciones: List<Notificacion>
)
