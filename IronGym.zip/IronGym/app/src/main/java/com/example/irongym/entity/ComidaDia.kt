package com.example.irongym.entity

data class ComidaDia(
    val id: Int,
    val dia_dieta_id: Int,
    val nombre: String,
    val descripcion: String
)