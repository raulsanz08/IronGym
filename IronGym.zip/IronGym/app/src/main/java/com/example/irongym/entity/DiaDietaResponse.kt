package com.example.irongym.entity

data class DiaDietaResponse(
    val success: Boolean,
    val dias: List<DiaDieta>
)
