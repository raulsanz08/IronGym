package com.example.irongym.entity

data class DesafioResponse(
    val success: Boolean,
    val desafios: List<Desafio>
)

