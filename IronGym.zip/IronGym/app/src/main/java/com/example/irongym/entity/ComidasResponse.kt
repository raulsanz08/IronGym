package com.example.irongym.entity

data class ComidasResponse(
    val success: Boolean,
    val comidas: List<ComidaDia>
)