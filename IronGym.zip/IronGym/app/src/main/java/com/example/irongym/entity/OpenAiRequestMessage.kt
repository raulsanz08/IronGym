package com.example.irongym.entity

data class OpenAiRequestMessage(
    val role: String,
    val content: String
)
